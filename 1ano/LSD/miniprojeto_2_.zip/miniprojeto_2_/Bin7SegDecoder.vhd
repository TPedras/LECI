library IEEE;
use IEEE.STD_LOGIC_1164.all;

entity Bin7SegDecoder is
  port(
    binInput : in  std_logic_vector(3 downto 0);  -- 4-bit binary input
    decOut_n : out std_logic_vector(6 downto 0)   -- 7-seg output (active-low)
  );
end Bin7SegDecoder;

architecture Behavioral of Bin7SegDecoder is
begin
  -- Segment order: g f e d c b a (MSB to LSB)
  -- Active-low encoding (0 = segment ON, 1 = OFF)
  decOut_n <= 
    "1000000" when binInput = "0000" else  -- 0
    "1111001" when binInput = "0001" else  -- 1
    "0100100" when binInput = "0010" else  -- 2
    "0110000" when binInput = "0011" else  -- 3
    "0011001" when binInput = "0100" else  -- 4
    "0010010" when binInput = "0101" else  -- 5
    "0000010" when binInput = "0110" else  -- 6
    "1111000" when binInput = "0111" else  -- 7
    "0000000" when binInput = "1000" else  -- 8
    "1000000";                             -- Default (0)
end Behavioral;