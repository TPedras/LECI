onerror {exit -code 1}
vlib work
vcom -work work maquinas_vendas.vho
vcom -work work Waveform.vwf.vht
vsim -voptargs="+acc" -c -t 1ps -L cycloneive -L altera -L altera_mf -L 220model -L sgate -L altera_lnsim work.maquinas_vendas_vhd_vec_tst
vcd file -direction maquinas_vendas.msim.vcd
vcd add -internal maquinas_vendas_vhd_vec_tst/*
vcd add -internal maquinas_vendas_vhd_vec_tst/i1/*
proc simTimestamp {} {
    echo "Simulation time: $::now ps"
    if { [string equal running [runStatus]] } {
        after 2500 simTimestamp
    }
}
after 2500 simTimestamp
run -all
quit -f
