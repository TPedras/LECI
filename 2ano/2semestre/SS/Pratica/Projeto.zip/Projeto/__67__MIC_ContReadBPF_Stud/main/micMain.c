/* ********************************************************************************************************************************* 
 * Microphone test - ADC in continuous mode and time-domain BP filtering 
 * Paulo Pedreiras, Pedro Fonseca, Luis Moutinho 2026/Apr.
 * 
 * Tested:
 *  ESP32-C6 DevKitC-1
 * 
 * - Basic use of the ADC to get and process sound samples.
 * - Uses continuous mode ADC operation, to allow higher frequencies
 * - Signal is processed by a Band-Pass filter, in the time-domain, to identify defined frequencies 
 *  
 * Microphone is a MEMS Adafruit Silicon MEMS Microphone Breakout - SPW2430.
 *     Supplied with 3.3-5V, output at DC pin has a 0.7 V and a 100 mVpp "when talking near". 
 *      In my case I had around 1 V. So the attenuation cannot be 0 dB. 
 *      I have used 2.5 dB (vref/0.7), to get 1.3 to 1.5 volts for Vref+ and avoid saturation
 *      Check other mics to see if this is normal.  
 * 
 *  
 * Bibliography: 
 *      https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/peripherals/adc/index.html
 *      https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/peripherals/adc/adc_continuous.html 
 *      https://docs.espressif.com/projects/esp-dsp/en/latest/esp32/esp-dsp-library.html      
 * 
 * Based on the sample code  provided by EspressIF:
 *      https://github.com/espressif/esp-idf/tree/47faecc3/examples/peripherals/adc/continuous_read 
 * 
 * NOTE: must run idf.py add-dependency "espressif/esp-dsp" when creating a new project using dsp functionality
 ***********************************************************************************************************************************/ 

/* ********************************* 
 * Includes
 ***********************************/
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "sdkconfig.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"      // FreeRTOS includes
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include "esp_adc/adc_continuous.h" // For ESP ADC
#include "esp_dsp.h"                // For ESP DSP functions
#include "esp_private/esp_clk.h"    // For ESP clock functions
#include "driver/gpio.h"            // Necessário para controlar os pinos (LED)

/* ********************************
 * Global defines 
 **********************************/
#define MICEX_ADC_UNIT                    ADC_UNIT_1
#define MICEX_ADC_CONV_MODE               ADC_CONV_SINGLE_UNIT_1
#define MICEX_ADC_ATTEN                   ADC_ATTEN_DB_2_5            // Use Vref/0.75, 1.3 ... 1.5 V
#define MICEX_ADC_BIT_WIDTH               SOC_ADC_DIGI_MAX_BITWIDTH   // 12 bits resolution (maximum)

#define MICEX_ADC_FRAME_SIZE             512                           /* ADC frame size, in bytes */
#define MICEX_ADC_BUF_SIZE               (4 * MICEX_ADC_FRAME_SIZE)    /* Internal buffer, should an integer multiple of the frame size to avoid incomplete frames */
#define MICEX_ADC_SAMPLE_FREQ            (20 * 1000)                   /* Sample frequency, in Hz. Notice that there are lower and higher bounds*/

#define MICEX_SOUND_SAMPLES_BUF_SIZE     2048 /* IMPORTANT: If FFT is to be used, must be must be a power of two */
                                              /* For time-domain conv. filters there is no such restriction */
                                              
#define MAX_FILT_IR_LEN                 200     /* Maximum IR filter length */

/* Frequencias dos simbolos (Turma 5, NMECs: 116113 e 125413)
   F0 = 5*500 = 2500Hz
   F1 = 2500+700+9*20 = 3380Hz
   F2 = 3380+700+180 = 4260Hz */
#define FREQ0                            2500
#define FREQ1                            3380
#define FREQ2                            4260

#define LED_GPIO                         11 
#define SOUND_THRESHOLD                  50.0f  /* limiar de som para deteção */

const int SEQ_ABRIR[4] = {0, 1, 2, 0};
const int SEQ_FECHAR[4] = {2, 1, 0, 2};

int detected_seq[4] = {-1, -1, -1, -1};
int seq_idx = 0;
int last_symbol = -1;
int silence_count = 0;

/* Global variable declarations */
static adc_channel_t channel[1] = {ADC_CHANNEL_3};  // Mic on ADC channel 3
static TaskHandle_t s_task_handle;

static const char *TAG = "MIC_EXAMPLE";

/* ADC - Variables to hold data acquisition and parsing */
__attribute__((aligned(16))) uint8_t result[MICEX_ADC_FRAME_SIZE] = {0}; // Buffer where the results of a continuous read are placed   
__attribute__((aligned(16))) adc_continuous_data_t parsed_data[MICEX_ADC_FRAME_SIZE / SOC_ADC_DIGI_RESULT_BYTES]; // Buffer where frame parsed data is placed 

/* FreeRTOS tasks and IPC */
#define PROCESSOR_TASK_STACK_SIZE       8192            // Accomodate calls to dsp functions, log, user vars, ...
#define PROCESSOR_TASK_PRIORITY	( tskIDLE_PRIORITY + 4 )
QueueHandle_t XQ;    /* Queue handle */

// Impulse reponse filter 
__attribute__((aligned(16))) float h_f0[151] = {-0.000361579334616f, 0.000162099328389f, 0.000645423677402f, 0.000793871457360f, 0.000470161017624f, -0.000201633932768f, -0.000864425436137f, -0.001100199099421f, -0.000675592129842f, 0.000272584348526f, 0.001243426434454f, 0.001613059947951f, 0.001011784516284f, -0.000377675376689f, -0.001817347919223f, -0.002377772822822f, -0.001509245604744f, 0.000515351024004f, 0.002610238016727f, 0.003427626915224f, 0.002192361485287f, -0.000679800867545f, -0.003632810127457f, -0.004780456437120f, -0.003076888141899f, 0.000861376454912f, 0.004880835853860f, 0.006436102555524f, 0.004167852450724f, -0.001047364076032f, -0.006334527101267f, -0.008374979320066f, -0.005458045087384f, 0.001223048968218f, 0.007958972221583f, 0.010557887811078f, 0.006927253018665f, -0.001372980262334f, -0.009705615868248f, -0.012927137805922f, -0.008542331859163f, 0.001482328000301f, 0.011514697218807f, 0.015408944946997f, 0.010258161224637f, -0.001538214939053f, -0.013318492018792f, -0.017916980353270f, -0.012019463369777f, 0.001530907379635f, 0.015045145693933f, 0.020356865597050f, 0.013763401505872f, -0.001454760819106f, -0.016622841917277f, -0.022631335292748f, -0.015422814133481f, 0.001308836841077f, 0.017984026682614f, 0.024645737622828f, 0.016929890227598f, -0.001097135572103f, -0.019069403891216f, -0.026313514027078f, -0.018220051378239f, 0.000828420832439f, 0.019831434926239f, 0.027561295409471f, 0.019235784341110f, -0.000515649968234f, -0.020237110336266f, -0.028333274114141f, -0.019930163051824f, 0.000175054252476f, 0.020269813804152f, 0.028594557211571f, 0.020269813804152f, 0.000175054252476f, -0.019930163051824f, -0.028333274114141f, -0.020237110336266f, -0.000515649968234f, 0.019235784341110f, 0.027561295409471f, 0.019831434926239f, 0.000828420832439f, -0.018220051378239f, -0.026313514027078f, -0.019069403891216f, -0.001097135572103f, 0.016929890227598f, 0.024645737622828f, 0.017984026682614f, 0.001308836841077f, -0.015422814133481f, -0.022631335292748f, -0.016622841917277f, -0.001454760819106f, 0.013763401505872f, 0.020356865597050f, 0.015045145693933f, 0.001530907379635f, -0.012019463369777f, -0.017916980353270f, -0.013318492018792f, -0.001538214939053f, 0.010258161224637f, 0.015408944946997f, 0.011514697218807f, 0.001482328000301f, -0.008542331859163f, -0.012927137805922f, -0.009705615868248f, -0.001372980262334f, 0.006927253018665f, 0.010557887811078f, 0.007958972221583f, 0.001223048968218f, -0.005458045087384f, -0.008374979320066f, -0.006334527101267f, -0.001047364076032f, 0.004167852450724f, 0.006436102555524f, 0.004880835853860f, 0.000861376454912f, -0.003076888141899f, -0.004780456437120f, -0.003632810127457f, -0.000679800867545f, 0.002192361485287f, 0.003427626915224f, 0.002610238016727f, 0.000515351024004f, -0.001509245604744f, -0.002377772822822f, -0.001817347919223f, -0.000377675376689f, 0.001011784516284f, 0.001613059947951f, 0.001243426434454f, 0.000272584348526f, -0.000675592129842f, -0.001100199099421f, -0.000864425436137f, -0.000201633932768f, 0.000470161017624f, 0.000793871457360f, 0.000645423677402f, 0.000162099328389f, -0.000361579334616f};

__attribute__((aligned(16))) float h_f1[151] = {-0.000444949402381f, -0.000706489096884f, -0.000238756220335f, 0.000548387440593f, 0.000851788647566f, 0.000265722436310f, -0.000719030260562f, -0.001086033981734f, -0.000305865039944f, 0.000979400243977f, 0.001427239619813f, 0.000353317299531f, -0.001351965740769f, -0.001889279446309f, -0.000398602012844f, 0.001857895504403f, 0.002480910292693f, 0.000429000722519f, -0.002515776976272f, -0.003205018878292f, -0.000429154721574f,0.003340364968078f, 0.004058137179933f, 0.000381871006277f, -0.004341428604095f, -0.005030258258185f, -0.000269093677849f, 0.005522762045631f, 0.006104969582285f, 0.000072990600958f, -0.006881418557952f, -0.007259904750054f, 0.000222902957467f, 0.008407218128289f, 0.008467498050564f, -0.000632546952374f, -0.010082566528161f, -0.009696010450671f, 0.001166330201115f, 0.011882609032501f, 0.010910781164769f, -0.001830137699417f, -0.013775725702264f, -0.012075646782935f, 0.002624608627094f, 0.015724358049172f, 0.013154460664048f, -0.003544633118616f, -0.017686139931056f, -0.014112639471574f, 0.004579124084943f, 0.019615289582024f, 0.014918661680753f, -0.005711086346669f, -0.021464205628946f, -0.015545444752854f, 0.006917989819209f, 0.023185198559640f, 0.015971533377846f, -0.008172437316425f, -0.024732281028860f, -0.016182040444347f,0.009443101593665f, 0.026062936085122f, 0.016169294723037f, -0.010695891415482f, -0.027139782145004f, -0.015933163995967f, 0.011895293535584f, 0.027932057387453f, 0.015481038745117f, -0.013005827244943f, -0.028416854024771f, -0.014827478654590f, 0.013993541165643f, 0.028580044253084f, 0.013993541165643f, -0.014827478654590f, -0.028416854024771f, -0.013005827244943f, 0.015481038745117f, 0.027932057387453f, 0.011895293535584f, -0.015933163995967f, -0.027139782145004f, -0.010695891415482f, 0.016169294723037f, 0.026062936085122f, 0.009443101593665f, -0.016182040444347f, -0.024732281028860f, -0.008172437316425f, 0.015971533377846f, 0.023185198559640f, 0.006917989819209f, -0.015545444752854f, -0.021464205628946f, -0.005711086346669f, 0.014918661680753f, 0.019615289582024f, 0.004579124084943f, -0.014112639471574f, -0.017686139931056f,-0.003544633118616f, 0.013154460664048f, 0.015724358049172f, 0.002624608627094f, -0.012075646782935f, -0.013775725702264f, -0.001830137699417f, 0.010910781164769f, 0.011882609032501f, 0.001166330201115f, -0.009696010450671f, -0.010082566528161f, -0.000632546952374f, 0.008467498050564f, 0.008407218128289f, 0.000222902957467f, -0.007259904750054f, -0.006881418557952f, 0.000072990600958f, 0.006104969582285f, 0.005522762045631f, -0.000269093677849f, -0.005030258258185f, -0.004341428604095f, 0.000381871006277f, 0.004058137179933f, 0.003340364968078f, -0.000429154721574f, -0.003205018878292f, -0.002515776976272f, 0.000429000722519f, 0.002480910292693f, 0.001857895504403f, -0.000398602012844f, -0.001889279446309f, -0.001351965740769f, 0.000353317299531f, 0.001427239619813f, 0.000979400243977f, -0.000305865039944f, -0.001086033981734f,-0.000719030260562f, 0.000265722436310f, 0.000851788647566f, 0.000548387440593f, -0.000238756220335f, -0.000706489096884f, -0.000444949402381f};

__attribute__((aligned(16))) float h_f2[151] = {0.000632554587372f, -0.000115144221424f, -0.000760319297217f, -0.000249729026260f, 0.000746484498336f, 0.000668291776233f, -0.000538362001019f, -0.001069487789887f, 0.000096544252534f, 0.001338642991194f, 0.000572311236965f, -0.001329397313020f, -0.001380176011758f, 0.000903767776199f, 0.002139429700646f, 0.000005262557297f, -0.002580812652751f, -0.001328281731814f, 0.002416527916790f, 0.002819891385220f, -0.001439991317874f, -0.004072688853650f, -0.000365214962819f, 0.004598979955087f, 0.002747326414130f, -0.003971372011621f, -0.005179228502150f, 0.001987885128333f, 0.006946087773866f, 0.001191290545417f, -0.007322850819331f, -0.004991245416663f, 0.005803120952012f, 0.008493116818606f, -0.002314113653751f, -0.010633161598324f, -0.002656788117412f, 0.010492655399902f, 0.008083600286852f, -0.007603706153335f, -0.012593597337880f, 0.002177296543542f, 0.014800483264042f, 0.004831096468631f, -0.013700213107428f, -0.011865141567243f, 0.009019142639615f, 0.017109275973518f, -0.001403147854651f, -0.018954786978052f, -0.007629992396409f, 0.016469754248826f, 0.015991008836209f, -0.009736816306800f, -0.021515061062160f, -0.000053051238140f, 0.022532357425555f, 0.010802373263209f, -0.018359313005197f, -0.019975312296942f, 0.009565519410050f, 0.025223863957154f, 0.002075546347980f, -0.025010733316964f, -0.013960985846363f, 0.019057639002824f, 0.023276067088105f, -0.008486625883356f, -0.027700414311875f, -0.004399331739944f, 0.026016337408106f, 0.016652681017947f, -0.018452387687269f, -0.025402059030036f, 0.006662439730687f, 0.028570665098259f, 0.006662439730687f, -0.025402059030036f, -0.018452387687269f, 0.016652681017947f, 0.026016337408106f, -0.004399331739944f, -0.027700414311875f, -0.008486625883356f, 0.023276067088105f, 0.019057639002824f, -0.013960985846363f, -0.025010733316964f, 0.002075546347980f, 0.025223863957154f, 0.009565519410050f, -0.019975312296942f, -0.018359313005197f, 0.010802373263209f, 0.022532357425555f, -0.000053051238140f, -0.021515061062160f, -0.009736816306800f, 0.015991008836209f, 0.016469754248826f, -0.007629992396409f, -0.018954786978052f, -0.001403147854651f, 0.017109275973518f, 0.009019142639615f, -0.011865141567243f, -0.013700213107428f, 0.004831096468631f, 0.014800483264042f, 0.002177296543542f, -0.012593597337880f, -0.007603706153335f, 0.008083600286852f, 0.010492655399902f, -0.002656788117412f, -0.010633161598324f, -0.002314113653751f, 0.008493116818606f, 0.005803120952012f, -0.004991245416663f, -0.007322850819331f, 0.001191290545417f, 0.006946087773866f, 0.001987885128333f, -0.005179228502150f, -0.003971372011621f, 0.002747326414130f, 0.004598979955087f, -0.000365214962819f, -0.004072688853650f, -0.001439991317874f, 0.002819891385220f, 0.002416527916790f, -0.001328281731814f, -0.002580812652752f, 0.000005262557297f, 0.002139429700646f, 0.000903767776199f, -0.001380176011758f, -0.001329397313020f, 0.000572311236965f, 0.001338642991194f, 0.000096544252534f, -0.001069487789887f,-0.000538362001019f, 0.000668291776233f, 0.000746484498336f, -0.000249729026260f, -0.000760319297217f, -0.000115144221424f, 0.000632554587372f};

/* *************************************************************** 
 * Function prototypes 
 *****************************************************************/
 static void continuous_adc_init(adc_channel_t *channel, uint8_t channel_num, adc_continuous_handle_t *out_handle);
 static bool s_conv_done_cb(adc_continuous_handle_t handle, const adc_continuous_evt_data_t *edata, void *user_data);
 static void pv_processor_task(void *pvParam);

/******************************************************************* 
 * The main task 
 *******************************************************************/
void app_main(void)
{
    /* Variable declarations */
    esp_err_t ret;          // Generic return code variable
    esp_err_t parse_ret;    // return code of ADC frame parse function 
    uint32_t ret_num = 0;   // Length of bytes return by a read operation
    uint32_t sb_count = 0;   // For counting the number of acquired samples    
    uint32_t num_parsed_samples = 0;    // To count the number of parsed samples
    
    adc_continuous_evt_cbs_t cbs;   // Variable for setting callback type (internal poll full, or frame conversion completed)    
    adc_continuous_handle_t handle = NULL;  //Handle for ADC          

    float * sound_samp_buf_ADC;   // Buffer to hold sound samples. Sound buffers are float because conv() function requires float parameters - avoid conversions 
    
    /* Variable inits */
    memset(result, 0x00, MICEX_ADC_FRAME_SIZE); // Init frame buffer     
    sound_samp_buf_ADC = heap_caps_malloc(sizeof(float) * MICEX_SOUND_SAMPLES_BUF_SIZE, MALLOC_CAP_DMA);     

    s_task_handle = xTaskGetCurrentTaskHandle();    // Get handle of the current task

    cbs.on_conv_done = s_conv_done_cb;  // Callback called when one conversion frame is done     
    cbs.on_pool_ovf = NULL;          // Don't set callback for internbal buffer overflow         

    /* Set log level */
    /* Debug allow to see variable values */
    /* Info only shows the decision */
    /* Verbose shows a trace of calls an some additional vars*/
    esp_log_level_set(TAG,ESP_LOG_DEBUG);

    // Inicia e configura o LED
    gpio_reset_pin(LED_GPIO);                       
    gpio_set_direction(LED_GPIO, GPIO_MODE_OUTPUT); 
    gpio_set_level(LED_GPIO, 0);                    



    /* Processor task and Queue inits */
    XQ=xQueueCreate(1, sizeof(float)*MICEX_SOUND_SAMPLES_BUF_SIZE); // Create queue to store one full sample period of sound
    xTaskCreate(pv_processor_task, "Processor", PROCESSOR_TASK_STACK_SIZE, NULL, PROCESSOR_TASK_PRIORITY, NULL );

    /* Init ADC */
    continuous_adc_init(channel, sizeof(channel) / sizeof(adc_channel_t), &handle); // Call init function
    ESP_ERROR_CHECK(adc_continuous_register_event_callbacks(handle, &cbs, NULL));   // Regiter callbacks
    ESP_ERROR_CHECK(adc_continuous_start(handle));                                  // Start the ADC

    /* Infinite loop - wait for data and process it */
    /* Synchronization with ADC is obtained via the ulTaskNotifyTake(pdTRUE, portMAX_DELAY); call */
    /*     that assures that processing does not proceed until a notification that a frame was acquired*/
    while (1) {        
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY); // Wait for a new frame

        while (1) {
            ret = adc_continuous_read(handle, result, MICEX_ADC_FRAME_SIZE, &ret_num, 0);
            if (ret == ESP_OK) {
                ESP_LOGV(TAG, "ret is %x, ret_num is %"PRIu32" bytes", ret, ret_num);                
                /* One frame received. Extract samples from frame and put them on sound sample buffer*/
                parse_ret = adc_continuous_parse_data(handle, result, ret_num, parsed_data, &num_parsed_samples);
                if (parse_ret == ESP_OK) {
                    
                    for (int i = 0; i < num_parsed_samples; i++) {
                        sound_samp_buf_ADC[sb_count] = (float) parsed_data[i].raw_data;                           
                        sb_count+=1;
                        if(sb_count == MICEX_SOUND_SAMPLES_BUF_SIZE) { // The sound buffer is full. Process it ... */
                            ESP_LOGD(TAG, "sound buffer acquired. Time to process ...\n");                
                            xQueueSend(XQ,(void *)sound_samp_buf_ADC,0);     // Places the sound buffer in the queue. If the queue is full skip it (ticksTo Wait set to 0)
                                                                        // The consumer/processing task is automatically waked if blocked in the Queue
                            sb_count = 0;
                        }
                    }

                } else {
                    ESP_LOGE(TAG, "Data parsing failed: %s", esp_err_to_name(parse_ret));
                }
                /*                  
                 * To avoid a task watchdog timeout, add a delay here. 
                 */
                vTaskDelay(1);
            } else if (ret == ESP_ERR_TIMEOUT) {
                //We try to read `EXAMPLE_READ_LEN` until API returns timeout, which means there's no available data
                break;
            }
        }
    }

    ESP_ERROR_CHECK(adc_continuous_stop(handle));
    ESP_ERROR_CHECK(adc_continuous_deinit(handle));
}


/* **********************************************************************************************
 * Task activated when there is a full buffer of sound samples data available
 * The task reads a queue in blocking mode. This wait it awakes whenever the ADC processing code
 *      (the app_main taks in the case) delivers a new full buffer of data. 
 * Note that the use of a Queue and two separate buffers (ADC and processing) decouples the 
 *      acquisition from processing. I.e., processing can take as much time as needed without race conditions
 *      or any other sort of interference. The cost is overhead ...
 ************************************************************************************************/
void pv_processor_task(void *pvParam)
{
    /* Local vars, for auxiliary computations */    
    int n;        
    float * sound_samp_buf_proc;       // Buffer to hold sound samples. Buffers are float because conv() function requires float parameters - avoid conversions     
    float * filtered_samp_buf;         
    
    /* Variable inits */
    sound_samp_buf_proc = heap_caps_malloc(sizeof(float) * MICEX_SOUND_SAMPLES_BUF_SIZE, MALLOC_CAP_DMA);         
    filtered_samp_buf = heap_caps_malloc(sizeof(float) * (MICEX_SOUND_SAMPLES_BUF_SIZE + MAX_FILT_IR_LEN), MALLOC_CAP_DMA);

    /* Infinite processing loop */
    for(;;) {
        /* Waits for new data */
        xQueueReceive(XQ,(void *)sound_samp_buf_proc,portMAX_DELAY); // Reads a sound sample. Blocks if queue is empty.
        ESP_LOGV(TAG, "Process Task got a buffer!");

        // Remove o offset DC do sinal
        float mean_dc = 0;
        for (n = 0; n < MICEX_SOUND_SAMPLES_BUF_SIZE; n++) {
            mean_dc += sound_samp_buf_proc[n];
        }
        mean_dc /= MICEX_SOUND_SAMPLES_BUF_SIZE;

        for (n = 0; n < MICEX_SOUND_SAMPLES_BUF_SIZE; n++) {
            sound_samp_buf_proc[n] -= mean_dc;
        }

        // Aplicar a convolucao para cada uma das frequencias alvo
        int fir_len = sizeof(h_f0) / sizeof(float);
        int conv_out_len = MICEX_SOUND_SAMPLES_BUF_SIZE + fir_len - 1;
        float energy0 = 0, energy1 = 0, energy2 = 0;

        // Filtro F0
        dsps_conv_f32(sound_samp_buf_proc, MICEX_SOUND_SAMPLES_BUF_SIZE, h_f0, fir_len, filtered_samp_buf);
        for (n = 0; n < conv_out_len; n++) {
            if (filtered_samp_buf[n] < 0) {
                energy0 -= filtered_samp_buf[n];
            } else {
                energy0 += filtered_samp_buf[n];
            }
        }
        energy0 /= conv_out_len;

        // Filtro F1
        dsps_conv_f32(sound_samp_buf_proc, MICEX_SOUND_SAMPLES_BUF_SIZE, h_f1, fir_len, filtered_samp_buf);
        for (n = 0; n < conv_out_len; n++) {
            if (filtered_samp_buf[n] < 0) {
                energy1 -= filtered_samp_buf[n];
            } else {
                energy1 += filtered_samp_buf[n];
            }
        }
        energy1 /= conv_out_len;

        // Filtro F2
        dsps_conv_f32(sound_samp_buf_proc, MICEX_SOUND_SAMPLES_BUF_SIZE, h_f2, fir_len, filtered_samp_buf);
        for (n = 0; n < conv_out_len; n++) {
            if (filtered_samp_buf[n] < 0) {
                energy2 -= filtered_samp_buf[n];
            } else {
                energy2 += filtered_samp_buf[n];
            }
        }
        energy2 /= conv_out_len;

        // Decide que simbolo e baseado na energia
        int current_detected = -1;
        
        if (energy0 > SOUND_THRESHOLD && energy0 > energy1 && energy0 > energy2) {
            current_detected = 0;
        } else if (energy1 > SOUND_THRESHOLD && energy1 > energy0 && energy1 > energy2) {
            current_detected = 1;
        } else if (energy2 > SOUND_THRESHOLD && energy2 > energy0 && energy2 > energy1) {
            current_detected = 2;
        }

        if (current_detected != -1) {
            if (current_detected != last_symbol) {
                ESP_LOGI(TAG, "Simbolo detetado: %d", current_detected);
                detected_seq[seq_idx++] = current_detected;
                last_symbol = current_detected;
                silence_count = 0;

                // Avaliar se a sequencia esta completa e correta
                if (seq_idx == 4) {
                    int ok_abrir = 1;
                    int ok_fechar = 1;
                    
                    for(int i = 0; i < 4; i++) {
                        if (detected_seq[i] != SEQ_ABRIR[i]) ok_abrir = 0;
                        if (detected_seq[i] != SEQ_FECHAR[i]) ok_fechar = 0;
                    }

                    if (ok_abrir) {
                        ESP_LOGI(TAG, "Porta ABERTA");
                        gpio_set_level(LED_GPIO, 1);
                    } else if (ok_fechar) {
                        ESP_LOGI(TAG, "Porta FECHADA");
                        gpio_set_level(LED_GPIO, 0);
                    } else {
                        ESP_LOGE(TAG, "Sequencia incorreta");
                        for (int i = 0; i < 25; i++) {
                            gpio_set_level(LED_GPIO, 1);
                            vTaskDelay(pdMS_TO_TICKS(100));
                            gpio_set_level(LED_GPIO, 0);
                            vTaskDelay(pdMS_TO_TICKS(100));
                        }
                    }
                    seq_idx = 0;
                    last_symbol = -1;
                }
            } else {
                silence_count = 0;
            }
        } else {
            silence_count++;
            if (silence_count > 3) last_symbol = -1; 
            
            if (silence_count > 40) {
                seq_idx = 0;
            }
        }
    }
}

/* Funções Auxiliares do ADC (Originais) */
static bool IRAM_ATTR s_conv_done_cb(adc_continuous_handle_t handle, const adc_continuous_evt_data_t *edata, void *user_data)
{
    BaseType_t mustYield = pdFALSE;
    vTaskNotifyGiveFromISR(s_task_handle, &mustYield);
    return (mustYield == pdTRUE);
}

static void continuous_adc_init(adc_channel_t *channel, uint8_t channel_num, adc_continuous_handle_t *out_handle)
{
    adc_continuous_handle_t handle = NULL;

    adc_continuous_handle_cfg_t adc_config = {
        .max_store_buf_size = MICEX_ADC_BUF_SIZE,
        .conv_frame_size = MICEX_ADC_FRAME_SIZE,
    };
    ESP_ERROR_CHECK(adc_continuous_new_handle(&adc_config, &handle));

    adc_continuous_config_t dig_cfg = {
        .sample_freq_hz = MICEX_ADC_SAMPLE_FREQ,
        .conv_mode = MICEX_ADC_CONV_MODE,
    };

    adc_digi_pattern_config_t adc_pattern[SOC_ADC_PATT_LEN_MAX] = {0};
    dig_cfg.pattern_num = channel_num;
    for (int i = 0; i < channel_num; i++) {
        adc_pattern[i].atten = MICEX_ADC_ATTEN;
        adc_pattern[i].channel = channel[i] & 0x7;
        adc_pattern[i].unit = MICEX_ADC_UNIT;
        adc_pattern[i].bit_width = MICEX_ADC_BIT_WIDTH;

        ESP_LOGI(TAG, "adc_pattern[%d].atten is :%"PRIx8, i, adc_pattern[i].atten);
        ESP_LOGI(TAG, "adc_pattern[%d].channel is :%"PRIx8, i, adc_pattern[i].channel);
        ESP_LOGI(TAG, "adc_pattern[%d].unit is :%"PRIx8, i, adc_pattern[i].unit);
    }
    dig_cfg.adc_pattern = adc_pattern;
    ESP_ERROR_CHECK(adc_continuous_config(handle, &dig_cfg));

    *out_handle = handle;
}
