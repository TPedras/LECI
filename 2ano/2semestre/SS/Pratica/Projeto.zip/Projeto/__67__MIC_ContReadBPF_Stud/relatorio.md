# Relatório de Implementação: Sistema de Controlo de Acesso via Tons

Este documento detalha as alterações realizadas ao código de base (`micMainOriginal.c`) para cumprir os requisitos do Mini-Projecto de Sensores e Sinais (2025-2026), documentados no ficheiro `SS2526_ProjectoFinal_Stud_V2.pdf`.

## 1. Frequências e Símbolos
Foi adicionada uma secção no início do código para definir os parâmetros dos alunos e as frequências correspondentes a cada símbolo:
* **Turma 5, NMECs: 116113 e 125413**
* **"0" (F0):** Turma * 500 Hz = 2500 Hz
* **"1" (F1):** F0 + 700 + ((soma algarismos % 10) * 20) = 2500 + 700 + (9 * 20) = 3380 Hz
* **"2" (F2):** F1 + 700 + ((soma algarismos % 10) * 20) = 3380 + 700 + 180 = 4260 Hz

Foram também definidas as sequências corretas (`SEQ_ABRIR` e `SEQ_FECHAR`), constituídas por 4 símbolos cada.

## 2. Remoção da Componente DC (DC Offset)
Os microfones analógicos introduzem um offset de tensão constante (DC). Se este offset não for retirado, cria um erro no processamento:
1. **Efeito de Borda (Degrau):** No início da convolução, o valor salta de 0 para o valor do offset de forma abrupta, contendo altas frequências que induzem artificialmente picos na saída do filtro FIR.
2. **Fuga DC:** O filtro FIR pode não atenuar absolutamente os 0 Hz, originando falsas leituras na energia global e ativando deteções fantasma.

**Alteração:** 
Adicionou-se um algoritmo para **cada novo bloco lido da queue**. Primeiramente calcula-se a média (`mean_dc`) dos 2048 pontos. Depois, percorre-se o mesmo bloco subtraindo este valor a cada amostra. O resultado é um bloco de áudio perfeitamente centrado em 0.

## 3. Aplicação de Filtros (Convolução)
O código original demonstrava a utilização de um filtro FIR com o auxílio da função `dsps_fir_init_f32()`. No entanto, o guião exige explicitamente que: 
> "A única função específica da biblioteca de DSP da EspressIF-IDF que pode ser usada é a de convolução (`dsps_conv_f32`)."

**Alteração:** 
1. Removeu-se a variável e a inicialização referentes à função `dsps_fir_init_f32`.
2. Na função `pv_processor_task`, a amostra lida do microfone (e limpa do seu valor DC) é processada recorrendo exclusivamente à função `dsps_conv_f32`. 
3. Como temos 3 tons possíveis a detetar em simultâneo, aplicamos a convolução três vezes seguidas sobre o mesmo bloco de som de entrada, com cada um dos filtros calculados (`h_f0`, `h_f1`, `h_f2`).

## 4. Cálculo de Energia e Limiares
Para determinar a presença de um tom, não basta filtrar; é necessário saber se a potência (ou amplitude média) do sinal resultante nessa gama de frequências é forte o suficiente, discriminando o sinal útil de mero ruído de fundo (silêncio).

**Alteração:**
* Calculou-se a média do valor absoluto (`fabsf`) do resultado de cada convolução. Esta métrica serve como uma "energia" equivalente computacionalmente rápida.
* Adicionou-se o macro `SOUND_THRESHOLD` (inicializado a `50.0f`). Se a energia do filtro for inferior a este valor, o som é considerado ruído. 
* Determina-se qual dos 3 filtros tem a **maior energia** para identificar univocamente qual a frequência presente naquele bloco de áudio.

## 5. Máquina de Estados (Lógica de Controlo de Acessos)
No código original, a deteção de sequência e respetiva sinalização com LED não existiam. Tivemos de conceber uma lógica que lide com amostragens contínuas de modo a não criar repetições indesejadas (ex: premir o botão durante 1 segundo resultaria em dezenas de falsas deteções de tom contínuo).

**Implementação:**
* **Debounce Temporal (Prevenção de Repetições):** Um símbolo só é aceite e registado na `detected_seq` se for **diferente** do `last_symbol`. 
* **Silêncio entre símbolos:** O `last_symbol` só sofre reset (volta a `-1`) se detetarmos "silêncio" (energia abaixo do limiar) durante um número curto de blocos de áudio (aproximadamente 300 ms). Assim, se o utilizador quiser inserir "0" e depois "0" novamente, precisa de fazer uma breve pausa entre eles.
* **Timeout de Sequência:** Adicionou-se um mecanismo de segurança em que, se houver um silêncio muito prolongado (ex: ~4 segundos, ou seja, > 40 blocos), o índice da sequência (`seq_idx`) sofre reset. Isto evita que o sistema espere infinitamente pelo último dígito de uma sequência esquecida.

## 6. Controlo do LED
A indicação física do estado da porta e da validação da sequência exigia a ativação e configuração do LED.
* Conforme indicado no guião, ligámos o sistema ao `GPIO11`. O pino foi inicializado como "Output" na função `app_main`.
* **Comportamentos implementados:**
  * Sequência de "Abrir" -> LED Ligado (Porta aberta).
  * Sequência de "Fechar" -> LED Desligado (Porta fechada).
  * Sequência errada -> Ciclo `for` que liga/desliga o LED de 100 em 100 milissegundos, perfazendo no total cerca de 5 segundos a piscar rapidamente, informando o utilizador do erro, seguido de reset da máquina de estados.